'use strict'

const buttonAuthorisation = document.querySelector('.bttn-authorisation');
const buttonRegistration = document.querySelector('.bttn-registr');
const pgRegistrContainer = document.querySelector('.pg-registr-container');
const pgAuthorisContainer = document.querySelector('.pg-authoris-container');

