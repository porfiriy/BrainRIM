# page-for-memory
Приложение для прокачки мозга по технологии NLP
можете попробовать приложение на сайте https://porfiriy.github.io/page-for-memory/
