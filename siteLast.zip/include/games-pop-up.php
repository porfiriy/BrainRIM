<div class="pop-up__container">
      <div class="pop-up">
         <div class="pop-up__title">
            Внимание
         </div>
         <div class="pop-up__description">
            Если вы перейдёте-результат не сохраниться
         </div>
         <div class="wrap__button">
            <form class="pop-up__form" action="#">
               <a href=" /pages/settings-page/settings-page.php" class="pop-up__ok">Ok</a>
               <a class="pop-up__cancel">Отмена</a>
            </form>
         </div>
      </div>
   </div>
   <div class="pop-up__container2">
      <div class="pop-up2">
         <div class="pop-up__title2">
            Внимание
         </div>
         <div class="pop-up__description2">
            Если вы перейдёте,результат не сохраниться
         </div>
         <div class="wrap__button2">
            <form class="pop-up__form2" action="#">
               <a href=" /index.php" class="pop-up__ok pop-up__ok2">Ok</a>
               <a class="pop-up__cancel pop-up__cancel2">Отмена</a>
            </form>
         </div>
      </div>
   </div>

   <div class="pop-up__container3">
      <div class="pop-up3">
         <div class="pop-up__title3">
            Внимание
         </div>
         <div class="pop-up__description3">
            Начать заново?
         </div>

         <div class="wrap__button3">
            <form class="pop-up__form3" action="#">
               <a onClick="window.location.reload();" class="pop-up__ok pop-up__ok3">Ok</a>
               <a class="pop-up__cancel pop-up__cancel3">Отмена</a>
            </form>
         </div>
      </div>
   </div>